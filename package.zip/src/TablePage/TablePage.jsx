import NavBar from "../NavBar/NavBar";
import FilterForm from "../FilterForm/FilterForm";
import Table from "../Table/Table";
import LeftPanelFilter from "../LeftPanelFilter/LeftPanelFilter";

import { useState, useEffect } from "react";
import { serverPath } from "../helpers/variables";
const TablePage = () => {

	const [data, setData] = useState(null)

	useEffect(()=>{
		fetch(serverPath + 'applications').then((res)=>{
			return res.json()
		}).then((data)=>{
			setData(data)
		})
	},[])

	useEffect(()=>{
		const storedData = localStorage.getItem('data');
		if(!storedData) {
			fetch(serverPath + 'applications').then((res)=>{
				return res.json()
				}).then((data)=>{
					setData(data)
				})
		}else{
			setData(JSON.parse(storedData));
		}
	},[]);


	//filter 
	const handleChange = (e) => {
        const filter= e.target.value;
        let filteredApplications;

		if(filter === 'all'){
			fetch(serverPath + 'applications').then((res)=>{
				return res.json()
			}).then((data)=>{
				setData(data)
			})
		}else{
			filteredApplications = data.filter((item) =>item.product === filter);

		}
		
		setData(filteredApplications)
    }

	// Пробую создать вторую функцию для фильтра
	const clickFilter = (e) => {
		const status = e.target.dataset.value

        let filteredApplications;

		if(status === 'all'){
			fetch(serverPath + 'applications').then((res)=>{
				return res.json()
			}).then((data)=>{
				setData(data)
			})
		}else{
			filteredApplications = data.filter((item) =>item.status === status);
		}

		setData(filteredApplications)
	}

	//localStorage
	useEffect(()=>{
		localStorage.setItem('data', JSON.stringify(data))
	}, [data])


	console.log(data)

    return (  
        <section className="with-nav body--dashboard">
		<NavBar/>

		<div className="left-panel blue-skin">

			<div className="left-panel__logo">
				<div className="left-panel__logo-title">CRM заявки</div>
				<div className="left-panel__logo-subtitle">учебный проект webcademy</div>
			</div>

			<div className="left-panel__user clearfix">
				<div className="left-panel__user-photo">
					<img src="img/avatars/avatar-128.jpg" alt="Avatar" />
				</div>
				<div className="left-panel__user-name">Петр <br />Васильевич</div>
			</div>

			<LeftPanelFilter/>

		</div>

		<div className="main-wrapper">
			<div className="container-fluid">
				<div className="admin-heading-1">Все заявки</div>

				<FilterForm handleChange={handleChange} clickFilter={clickFilter}/>
				{data && <Table data={data}/>}

			</div>
		</div>
	</section>
    );
}
 
export default TablePage
;