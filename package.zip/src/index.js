import React from 'react';
import ReactDOM from 'react-dom/client';
import { serverPath } from './helpers/variables';

import App from './App/App';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <App />
);
