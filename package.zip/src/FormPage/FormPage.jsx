import NavBar from "../NavBar/NavBar";
import AddForm from "../AddForm/AddForm";

import { useState, useEffect } from "react";
import { serverPath } from "../helpers/variables";
const FormPage = () => {

    const [data, setData] = useState(null)
    useEffect(()=>{
        fetch(serverPath + 'applications').then((res)=>{
            return res.json()
        }).then((data)=>{
            setData(data)
        })
    }, [])


    return ( 
        
        <section className="with-nav radial-bg flex-center body">
            <NavBar/>
            <div className="white-plate white-plate--payment">
                <div className="container-fluid">
                    <div className="white-plate__header text-center">
                        <p className="white-plate__logo">
                        <span>Форма</span> заявок
                        </p>
                    </div>
                <div className="white-plate__line-between white-plate__line-between--main"></div>
                    <AddForm/>
                </div>
            </div>
        </section>
    );
}


export default FormPage;